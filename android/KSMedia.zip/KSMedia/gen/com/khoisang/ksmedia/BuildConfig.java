/** Automatically generated file. DO NOT MODIFY */
package com.khoisang.ksmedia;

public final class BuildConfig {
	public final static boolean DEBUG = true;
}