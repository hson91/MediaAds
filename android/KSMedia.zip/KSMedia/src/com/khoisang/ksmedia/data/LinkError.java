package com.khoisang.ksmedia.data;

public class LinkError {
	public int Id;
	public String ListUrl;
}
