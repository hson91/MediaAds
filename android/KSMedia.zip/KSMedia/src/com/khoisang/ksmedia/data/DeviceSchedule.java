package com.khoisang.ksmedia.data;

import java.util.List;

public class DeviceSchedule {
	public Device device;
	public List<Schedule> schedule;
}
