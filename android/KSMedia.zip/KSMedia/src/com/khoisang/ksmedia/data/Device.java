package com.khoisang.ksmedia.data;

public class Device {
	public String deviceToken;
}
