package com.khoisang.ksmedia.api.structure;

import com.khoisang.ksmedia.data.DeviceSchedule;

public class OutputGetSchedule extends OutputBase {
	public DeviceSchedule data;
}
