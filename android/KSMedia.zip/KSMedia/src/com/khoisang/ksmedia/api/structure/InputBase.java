package com.khoisang.ksmedia.api.structure;

public abstract class InputBase {

}
