package com.khoisang.ksmedia.api.structure;

public abstract class OutputBase {
	public int status;
	public String message;
	public int time;
}
