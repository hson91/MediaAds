package com.khoisang.ksmedia.api.structure;

import com.khoisang.ksmedia.data.DeviceSchedule;

public class OutputGettingStarted extends OutputBase {
	public DeviceSchedule data;
}
