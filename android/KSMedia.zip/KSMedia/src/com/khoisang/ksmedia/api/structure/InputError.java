package com.khoisang.ksmedia.api.structure;

public class InputError extends InputBase {
	public int typeLog = 1;
	public String detailLog;
	public String tokenID;
}
