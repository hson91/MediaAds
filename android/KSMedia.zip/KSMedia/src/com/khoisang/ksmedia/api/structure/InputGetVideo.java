package com.khoisang.ksmedia.api.structure;

public class InputGetVideo extends InputBase {
	public long timeStart;
	public String tokenID;
}
