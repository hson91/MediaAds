package com.khoisang.ksmedia.api.structure;

public class InputGettingStarted extends InputBase {
	public String tokenID;
	public String deviceID;
	public String deviceName;
	public String deviceProducers;
	public int deviceOS;
	public String versionOS;
	public String coordinatesX;
	public String coordinatesY;
	public String macAddress;
	public String ipAddress;
	public String versionApp;
	public int deviceWidth;
	public int deviceHeight;
	public String deviceErrorsLog;
	public int typeSizeVideo;
	public int status;

}
