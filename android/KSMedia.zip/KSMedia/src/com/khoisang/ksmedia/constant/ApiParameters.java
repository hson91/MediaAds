package com.khoisang.ksmedia.constant;

public class ApiParameters {
	public static final String BODY_KEY = "data";
}
