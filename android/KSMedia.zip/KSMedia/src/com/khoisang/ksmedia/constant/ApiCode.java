package com.khoisang.ksmedia.constant;

public class ApiCode {
	public static final int SUCCESSFUL = 1;
}
