package com.khoisang.ksmedia.constant;

public class APIName {
	public static final int GETTING_STARTED = 1;
	public static final int GET_SCHEDULE = 2;
	public static final int ERROR = 3;
}
