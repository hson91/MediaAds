package com.khoisang.ksmedia.ui;

import android.app.Application;

public class MyApplication extends Application {
}
